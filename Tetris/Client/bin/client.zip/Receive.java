import java.io.*;
import java.net.*;


public class Receive extends Thread{
	private Socket client;
	
	public Receive(Socket socket) {
		this.client = socket;
	}
	
	public void run() {
		try {
			BufferedReader in = new BufferedReader(new InputStreamReader(client.getInputStream())); 
			String inputMessage;
			
			while(true) {
				inputMessage = in.readLine();
				
				System.out.println("����: " + inputMessage);
			}
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}
}
