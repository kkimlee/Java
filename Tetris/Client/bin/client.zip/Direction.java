import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Direction extends JFrame{
	
	public String message;
	
	public Direction() {
		setTitle("test");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Container c = getContentPane();
		c.addKeyListener(new KeyListener());
		
		c.setLayout(null);

		setSize(500,500);
		setVisible(true);
		c.setFocusable(true);
		c.requestFocus();
	}

	class KeyListener extends KeyAdapter {
		public void keyPressed(KeyEvent e) {
			int keyCode = e.getKeyCode();
			message = Integer.toString(keyCode);
		}
		
	}
	
}
