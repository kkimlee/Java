import java.io.*;
import java.net.*;
import java.util.*;

public class Send extends Thread{
private Socket client;
	
	public Send(Socket socket) {
		this.client = socket;
	}
	
	public void run() {
		try {
			BufferedWriter out = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
			Scanner scanner = new Scanner(System.in);
			String outMessage = null;
			while(true) {
				System.out.print("������>>");
				outMessage = scanner.nextLine();
				if(outMessage !=null) {
					out.write(outMessage + "\n");
					out.flush();
				}
			}
			
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} 	
	}

}
