import java.net.*;
import java.io.*;

public class Client {
	public static void main(String[] args) {
	
		try {
			
			Socket client = new Socket();
			client.bind(new InetSocketAddress("localhost",9998));
			client.connect(new InetSocketAddress("192.168.123.24",9999));
			
			
			Receive rec = new Receive(client);
			Send sen = new Send(client);
			
			rec.start();
			sen.start();
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} 
	}

}